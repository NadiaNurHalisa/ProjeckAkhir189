package Model;

public class Barang {
    String nama;
    int harga, kuantitas, totalHarga;
    public Barang(String nama, int harga, int kuantitas) {
        this.nama = nama;
        this.harga = harga;
        this.kuantitas = kuantitas;
        this.totalHarga = harga * kuantitas;
    }
    public String getNama() {
        return nama;
    }
    public int getHarga() {
        return harga;
    }
    public int getKuantitas() {
        return kuantitas;
    }
    public int getTotalHarga() {
        return totalHarga;
    }
    
    
}
